"""
Credit Risk & Loan Default Prediction - full analysis app
Author of analysis: Aphelele Siphelele Gwebityala (202430482) | NCPS730 Capstone
Run with:  streamlit run app.py

Folder layout expected:
    app.py
    models/  xgboost_calibrated.pkl, xgboost_raw.pkl, feature_names.pkl, schema.pkl
    assets/  cell*_*.png  (figures exported from the notebook)
All numbers shown in the analysis tabs are copied from the notebook outputs.
"""
import json
import pickle
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import shap
import streamlit as st

st.set_page_config(page_title="Credit Risk Analysis", layout="wide")
HERE = Path(__file__).parent


def find(name, *folders):
    for f in folders:
        p = HERE / f / name
        if p.exists():
            return p
    return HERE / name  # fall back to same folder


def fig(cell, caption, k=1):
    p = find(f"cell{cell}_{k}.png", "assets", ".")
    if p.exists():
        st.image(str(p), caption=caption, use_container_width=True)
    else:
        st.warning(f"Figure not found: {p.name}")


# ---------- model loading (SHAP / XGBoost base_score fix kept from original) ----------
def fix_xgboost_base_score(booster):
    """Some XGBoost versions save base_score as '[5E-1]', which older SHAP cannot read."""
    try:
        model_json = json.loads(booster.save_raw("json"))
        param = model_json["learner"]["learner_model_param"]
        bs = param["base_score"]
        if isinstance(bs, str) and bs.strip().startswith("["):
            param["base_score"] = bs.strip("[]")
            booster.load_model(bytearray(json.dumps(model_json), "utf-8"))
    except (KeyError, TypeError):
        pass
    return booster


@st.cache_resource
def load_artefacts():
    load = lambda n: pickle.load(open(find(n, "models", "."), "rb"))
    calibrated, raw_model = load("xgboost_calibrated.pkl"), load("xgboost_raw.pkl")
    feats, schema = load("feature_names.pkl"), load("schema.pkl")
    if hasattr(raw_model, "get_booster"):
        fix_xgboost_base_score(raw_model.get_booster())
    return calibrated, raw_model, feats, schema, shap.TreeExplainer(raw_model)


MODEL, RAW_MODEL, FEATURES, SCHEMA, EXPLAINER = load_artefacts()
CAT, CATVALS = SCHEMA["cat_cols"], SCHEMA["cat_values"]

# ---------- header ----------
st.title("Credit Risk & Loan Default Prediction")
st.markdown("**Analysis by Aphelele Siphelele Gwebityala (202430482)** · NCPS730 Capstone · "
            "Research prototype, not for real lending decisions.")

tabs = st.tabs(["1. Overview", "2. Data & EDA", "3. Statistical models", "4. Model comparison",
                "5. Scorecard & IV", "6. Calibration & risk bands", "7. Explainability (SHAP)",
                "8. Score an applicant"])

# ---------- 1. Overview ----------
with tabs[0]:
    st.header("What is this project about?")
    st.write("A lender wants to know how likely an applicant is to **default** (fail to repay). "
             "This is a *binary classification* problem: the answer is Default = 1 or Default = 0. "
             "The model also gives a **probability of default (PD)**, a number between 0 and 1.")
    c = st.columns(4)
    c[0].metric("Loans in dataset", "255,347")
    c[1].metric("Default rate", "11.6%")
    c[2].metric("Best test AUC (XGBoost)", "0.759")
    c[3].metric("Recall at 0.5 cut-off", "0.69")
    st.subheader("Steps followed")
    st.markdown("""
1. **Data understanding**: no missing values and no duplicates; 9 numeric and 7 categorical variables.
2. **Data preparation**: one-hot encoding, stratified 80/20 split (204,277 train / 51,070 test).
   Class imbalance is handled with class weights, **not** SMOTE.
3. **Modelling**: L1 logistic regression (primary), Probit and Logit inference, Random Forest, XGBoost.
4. **Evaluation**: AUC, recall, precision, F1, threshold tuning (Youden's J).
5. **Scorecard**: Weight of Evidence (WoE) and Information Value (IV).
6. **Calibration**: isotonic calibration so probabilities can be read as real risks.
7. **Explainability**: SHAP values, then three risk bands for decisions.
""")
    st.info("**Key finding:** `CreditScore` is one of the weakest predictors here (IV = 0.013). "
            "Age, interest rate and income matter much more.")

# ---------- 2. EDA ----------
with tabs[1]:
    st.header("Data understanding (EDA)")
    a, b = st.columns(2)
    with a:
        fig(5, "Class balance: about 1 in 9 loans defaults (imbalanced)")
    with b:
        fig(6, "Correlation matrix: no single variable is strongly correlated with Default")
    fig(7, "Default rate by Education, Employment type and Loan purpose")
    fig(8, "Default rate by decile of Interest rate, Credit score and Age")
    st.subheader("Chi-square tests: is each category linked to default?")
    chi = pd.DataFrame({
        "Variable": ["Education", "EmploymentType", "MaritalStatus", "HasMortgage",
                     "HasDependents", "LoanPurpose", "HasCoSigner"],
        "Chi-square": [214.0, 529.7, 200.4, 133.3, 306.9, 127.9, 390.3],
        "Degrees of freedom": [3, 3, 2, 1, 1, 4, 1],
        "p-value": ["3.9e-46", "1.7e-114", "3.1e-44", "8.0e-31", "1.1e-68", "1.1e-26", "7.1e-87"]})
    st.dataframe(chi, hide_index=True, use_container_width=True)
    st.caption("All p-values are far below 0.05, so every categorical variable is associated with default. "
               "Employment type is the strongest.")
    st.subheader("Default rate (%) by credit-score band and income quintile")
    seg = pd.DataFrame({"Q1": [19.6, 18.7, 17.3, 16.5], "Q2": [12.1, 11.2, 10.7, 10.1],
                        "Q3": [10.4, 10.4, 9.0, 8.5], "Q4": [10.4, 8.4, 8.1, 8.0],
                        "Q5": [9.8, 8.6, 8.0, 7.7]}, index=["Poor", "Fair", "Good", "Excellent"])
    st.dataframe(seg.style.background_gradient(cmap="RdYlGn_r", axis=None).format("{:.1f}"),
                 use_container_width=True)
    st.caption("Income changes default risk more than credit score does.")

# ---------- 3. Statistical models ----------
with tabs[2]:
    st.header("Logistic regression and Probit (statistical inference)")
    st.write("These models are fitted on the real (unbalanced) training data, so the p-values and "
             "fit statistics can be trusted.")
    c = st.columns(3)
    c[0].metric("Logit AIC", "129,287")
    c[1].metric("Logit BIC", "129,543")
    c[2].metric("McFadden pseudo-R²", "0.119")
    st.subheader("Strongest odds ratios (numeric variables are standardised)")
    odds = pd.DataFrame({
        "Variable": ["InterestRate", "EmploymentType_Unemployed", "Age", "LoanAmount",
                     "EmploymentType_Part-time", "Income", "MonthsEmployed",
                     "EmploymentType_Self-employed", "HasCoSigner_Yes", "HasDependents_Yes",
                     "MaritalStatus_Married", "LoanPurpose_Home"],
        "Odds ratio": [1.5814, 1.5617, 0.5571, 1.3503, 1.3166, 0.7104, 0.7138, 1.2782, 0.7692,
                       0.7767, 0.8113, 0.8312],
        "CI low": [1.5581, 1.4990, 0.5487, 1.3309, 1.2627, 0.7001, 0.7035, 1.2254, 0.7475, 0.7548,
                   0.7833, 0.7938],
        "CI high": [1.6051, 1.6271, 0.5656, 1.3700, 1.3729, 0.7208, 0.7243, 1.3332, 0.7915, 0.7992,
                    0.8403, 0.8704]})
    st.dataframe(odds, hide_index=True, use_container_width=True)
    st.markdown("**How to read this:** an odds ratio above 1 raises the odds of default; below 1 lowers them. "
                "For example, one standard deviation more interest rate multiplies the odds of default by about 1.58, "
                "while one standard deviation more age multiplies them by about 0.56.")
    st.subheader("Logit versus Probit")
    st.table(pd.DataFrame({"AIC": [129287, 129462], "BIC": [129543, 129718],
                           "McFadden R²": [0.1192, 0.1180]}, index=["Logit", "Probit"]))
    st.caption("The two are almost identical, so the link function does not matter. Logit is kept because "
               "odds ratios are easier to explain.")
    st.subheader("Hosmer-Lemeshow check (Logit, test set)")
    st.write("Statistic = 16.4, degrees of freedom = 8, p = 0.037. With 51,070 rows this test is very "
             "sensitive; the reliability table shows predicted and observed rates are close in every decile.")

# ---------- 4. Model comparison ----------
with tabs[3]:
    st.header("Model comparison (all class-weighted)")
    comp = pd.DataFrame({
        "5-fold CV AUC": ["0.746 ± 0.004", "0.749 ± 0.003", "0.753 ± 0.003"],
        "Test AUC": [0.7532, 0.7550, 0.7583],
        "Recall": [0.7009, 0.6510, 0.6913],
        "Precision": [0.2198, 0.2381, 0.2255],
        "F1": [0.3346, 0.3486, 0.3400],
        "Accuracy": [0.6763, 0.7175, 0.6884]},
        index=["Logistic + L1 (primary)", "Random Forest", "XGBoost (best)"])
    st.dataframe(comp, use_container_width=True)
    st.write("All three models perform almost the same (AUC about 0.75). XGBoost is best by a small margin.")
    a, b = st.columns(2)
    with a:
        fig(28, "ROC curves for the three models")
    with b:
        fig(29, "Confusion matrix of the best model")
    st.subheader("Precision versus recall")
    fig(31, "Precision and recall as the decision threshold changes")
    st.write("Precision of 0.60 is only reached at a threshold of 0.840, where recall falls to 0.077. "
             "So the target of high precision and high recall together cannot be met with these variables. "
             "The chosen cut-off favours **catching defaulters** (recall).")
    st.subheader("Youden's J threshold")
    c = st.columns(3)
    c[0].metric("J-optimal threshold", "0.508")
    c[1].metric("TPR / FPR", "0.682 / 0.300")
    c[2].metric("F1 at J-optimal", "0.344")
    fig(33, "ROC curve with the Youden optimum")
    st.caption("The J-optimal threshold (0.508) is very close to the default 0.5, so no extra adjustment is needed.")

# ---------- 5. Scorecard ----------
with tabs[4]:
    st.header("Weight of Evidence, Information Value and scorecard")
    st.write("**Information Value (IV)** measures how well a variable separates defaulters from non-defaulters. "
             "Rule of thumb: below 0.02 useless, 0.02-0.1 weak, 0.1-0.3 medium, 0.3-0.5 strong.")
    iv = pd.DataFrame({
        "Variable": ["Age", "InterestRate", "Income", "MonthsEmployed", "LoanAmount", "EmploymentType",
                     "HasCoSigner", "CreditScore", "HasDependents", "NumCreditLines", "Education",
                     "MaritalStatus", "LoanPurpose", "DTIRatio", "HasMortgage", "LoanTerm"],
        "IV": [0.2847, 0.1770, 0.1341, 0.0939, 0.0754, 0.0205, 0.0137, 0.0129, 0.0125, 0.0078,
               0.0076, 0.0066, 0.0051, 0.0050, 0.0049, 0.0001],
        "Strength": ["medium"] * 3 + ["weak"] * 3 + ["useless"] * 10}).set_index("Variable")
    st.bar_chart(iv["IV"])
    st.dataframe(iv, use_container_width=True)
    c = st.columns(3)
    c[0].metric("Scorecard AUC", "0.756")
    c[1].metric("XGBoost AUC", "0.758")
    c[2].metric("Points range (test)", "580 - 896")
    st.write("A simple points-based scorecard nearly matches XGBoost, so it is a strong choice for the "
             "regulator-facing layer, with XGBoost and SHAP used for deeper checks.")
    fig(38, "Scorecard points by actual outcome")

# ---------- 6. Calibration ----------
with tabs[5]:
    st.header("Calibration and risk bands")
    st.write("Tree models often give probabilities that are too high or too low. **Isotonic calibration** "
             "corrects this while keeping the ranking of applicants unchanged.")
    st.table(pd.DataFrame({"Hosmer-Lemeshow stat": [25642.9, 10.9], "p-value": ["< 0.0001", 0.2103],
                           "AUC": [0.7583, 0.7588]}, index=["XGBoost raw", "XGBoost calibrated"]))
    fig(41, "Calibration curve: calibrated probabilities follow the diagonal")
    st.subheader("Risk bands (calibrated probability)")
    bands = pd.DataFrame({"Applicants": [37976, 11625, 1469], "Share (%)": [74.4, 22.8, 2.9],
                          "Observed default rate (%)": [6.46, 23.24, 52.89]},
                         index=["Low (< 15%)", "Medium (15-40%)", "High (> 40%)"])
    st.dataframe(bands, use_container_width=True)
    st.bar_chart(bands["Observed default rate (%)"])
    st.caption("Observed default rates rise steadily from Low to High, so the bands separate risk well.")

# ---------- 7. SHAP ----------
with tabs[6]:
    st.header("Explainability with SHAP")
    st.write("SHAP shows how much each variable pushes a prediction up or down. It is computed on the "
             "pre-calibration XGBoost model; calibration only rescales the output, so the ranking of "
             "drivers stays valid.")
    a, b = st.columns(2)
    with a:
        fig(44, "Average impact of each variable")
    with b:
        fig(45, "Direction of impact (each dot is an applicant)")
    fig(46, "Example explanation for one applicant")

# ---------- 8. Live scoring ----------
with tabs[7]:
    st.header("Score an applicant")
    left, right = st.columns([1, 1.4])
    with left:
        raw = {
            "Age": st.slider("Age", 18, 90, 35),
            "Income": st.number_input("Annual income (R)", 5000.0, 300000.0, 60000.0, 1000.0),
            "LoanAmount": st.number_input("Loan amount (R)", 1000.0, 300000.0, 120000.0, 1000.0),
            "CreditScore": st.slider("Credit score", 300, 850, 600),
            "MonthsEmployed": st.slider("Months employed", 0, 240, 48),
            "NumCreditLines": st.slider("Number of credit lines", 1, 10, 3),
            "InterestRate": st.number_input("Interest rate (%)", 2.0, 30.0, 13.0, 0.1),
            "LoanTerm": st.selectbox("Loan term (months)", [12, 24, 36, 48, 60], index=2),
            "DTIRatio": st.number_input("Debt-to-income ratio", 0.0, 1.0, 0.4, 0.01),
        }
        for c in CAT:
            raw[c] = st.selectbox(c, CATVALS[c])

    X = (pd.get_dummies(pd.DataFrame([raw]), columns=CAT)
         .reindex(columns=FEATURES, fill_value=0).astype(float))
    pd_hat = float(MODEL.predict_proba(X)[:, 1][0])

    if pd_hat < 0.15:
        band, colour, rec = "LOW", "#2a9d8f", "Approve on standard terms."
    elif pd_hat < 0.40:
        band, colour, rec = "MEDIUM", "#e9c46a", "Review: consider a higher rate, a co-signer or a lower amount."
    else:
        band, colour, rec = "HIGH", "#e76f51", "Decline or send to manual underwriting."

    with right:
        st.metric("Probability of default", f"{pd_hat*100:.1f}%")
        st.markdown(f"<div style='padding:14px;border-radius:10px;background:{colour};color:#111;"
                    f"font-size:22px;font-weight:700;text-align:center'>{band} RISK</div>",
                    unsafe_allow_html=True)
        st.write("")
        st.info(rec)
        sv = EXPLAINER.shap_values(X)
        sv_row = sv[1][0] if isinstance(sv, list) and len(sv) > 1 else (sv[0][0] if isinstance(sv, list) else sv[0])
        base = np.array(EXPLAINER.expected_value).flatten()[-1]
        expl = shap.Explanation(values=sv_row, base_values=base, data=X.iloc[0].values,
                                feature_names=FEATURES)
        f = plt.figure()
        shap.plots.waterfall(expl, max_display=10, show=False)
        st.pyplot(f, bbox_inches="tight")
        plt.close(f)
        st.caption("Red bars push risk up; blue bars push it down. Values are on the model's log-odds scale.")

st.divider()
st.caption("Limits: precision at the 0.5 cut-off is low (about 0.23) because the model is tuned to catch "
           "defaulters (recall about 0.69). Test AUC is about 0.76.")
